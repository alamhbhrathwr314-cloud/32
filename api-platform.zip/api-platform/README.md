# API Platform

Spring Boot service: users register, get an API key, and call image-editing endpoints (done locally in Java, no external service) and an optional text endpoint. New users get 100 credits; each call costs 1.

The database is a JSON file saved in a PRIVATE GitHub repo (works with ONE running instance only).

## Environment variables
- GITHUB_TOKEN  - fine-grained token with Contents: Read and write on the data repo only
- GITHUB_REPO   - owner/repo-name of a PRIVATE repo used only for data
- GITHUB_BRANCH (default main), GITHUB_DATA_PATH (default data/db.json)
- MAX_USERS (default 500)
- ANTHROPIC_API_KEY - optional; without it /v1/chat returns 501

Without GITHUB_TOKEN the data lives in memory only (fine for local tests).

## Run locally
    mvn spring-boot:run

## Usage
    curl -X POST localhost:8080/auth/register -H 'Content-Type: application/json' \
      -d '{"email":"me@example.com","password":"12345678"}'

    curl -X POST localhost:8080/auth/keys -H 'Content-Type: application/json' \
      -d '{"email":"me@example.com","password":"12345678"}'

    curl localhost:8080/v1/me -H 'Authorization: Bearer sk_live_...'

    # ops: grayscale, invert, resize (width,height), rotate (angle=90|180|270), flip, blur (amount=1-10)
    curl -X POST localhost:8080/v1/image/process -H 'Authorization: Bearer sk_live_...' \
      -F image=@photo.jpg -F op=grayscale -o result.png

## Deploy on Render
New > Web Service > connect the GitHub repo > Language: Docker > Instance: Free > add the environment variables above.
